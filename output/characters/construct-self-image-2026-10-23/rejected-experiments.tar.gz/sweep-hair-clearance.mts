import {readFile,writeFile,mkdir} from 'node:fs/promises';import {transformSync} from 'esbuild';import * as THREE from 'three';
import {constructInspection,inspectionPalm,inspectionBodyCrossings} from './candidate-release/tests/helpers/construct-inspection.mjs';
const h=await constructInspection();h.at(0);(h.models as unknown as {constructs:Map<unknown,{update:()=>void}>}).constructs.get(h.rig)!.update=()=>{};
const source=await readFile(new URL('./candidate-release/packages/client/src/agents/ConstructSelfImage.ts',import.meta.url),'utf8'),folder=new URL('./hair-variants/',import.meta.url);await mkdir(folder,{recursive:true});const reach=new URL('./candidate-release/packages/client/src/agents/SpoonPerformance.ts',import.meta.url).href;
for(const z of [-.225,-.24,-.255,-.27]){
 const edited=source.replace("'./SpoonPerformance.js'",JSON.stringify(reach)).replace('new THREE.Vector3(0, 0, -.21)',`new THREE.Vector3(0, 0, ${z})`),file=new URL(`hair-${z}.mjs`,folder);await writeFile(file,transformSync(edited,{loader:'ts',format:'esm',target:'es2022'}).code);const {inspectConstructImage}=await import(file.href);h.at(4);inspectConstructImage(h.rig,4);h.rig.root.updateMatrixWorld(true);const palm=inspectionPalm(h.rig,'L'),gaps:Record<string,number|null>={};
 for(const name of ['Anatomical_head_and_hands','Close-cut_scalp_undercoat']){
  const mesh=h.rig.root.getObjectByName(name) as THREE.SkinnedMesh;mesh.skeleton.update();mesh.computeBoundingSphere();
  const hit=new THREE.Raycaster(palm.world.clone().addScaledVector(palm.normal,-.3),palm.normal,0,.8).intersectObject(mesh,false).find(hit=>[hit.face!.a,hit.face!.b,hit.face!.c].reduce((sum,id)=>sum+[0,1,2,3].reduce((s,k)=>s+(mesh.skeleton.bones[mesh.geometry.attributes.skinIndex.getComponent(id,k)].name==='head'?mesh.geometry.attributes.skinWeight.getComponent(id,k):0),0),0)>1.5);
  gaps[name]=hit?.point.distanceTo(palm.world)??null;
 }
 console.log(JSON.stringify({z,gaps,collisions:inspectionBodyCrossings(h.rig).map((c:any)=>({side:c.side,name:c.name,count:c.count}))}));
}
h.models.dispose();
