import * as THREE from "three";
import { reach } from "file:///Users/tianqizhong/ai_project/auto_matrix/output/characters/construct-self-image-2026-10-23/candidate-release/packages/client/src/agents/SpoonPerformance.ts";
const sleeves = /* @__PURE__ */ new WeakMap();
const feeling = /* @__PURE__ */ new WeakMap();
function prepareConstructSleeves(rig) {
  const mesh = rig.root.getObjectByName("Tailored_coat_upper"), geometry = mesh.geometry.clone(), fitted = geometry.clone();
  const position = geometry.attributes.position, output = fitted.attributes.position, moved = /* @__PURE__ */ new Set();
  for (const side of ["R", "L"]) {
    const joint = mesh.skeleton.bones.indexOf(rig.bones.get(`wrist_${side}`)), toWrist = mesh.skeleton.boneInverses[joint].clone().multiply(mesh.bindMatrix), back = toWrist.clone().invert();
    const axis = rig.bones.get(`wrist_${side}`).position.clone().normalize(), point = new THREE.Vector3();
    for (let id = 0; id < position.count; id++) {
      let weight = 0;
      for (let k = 0; k < 4; k++) {
        const bone = mesh.skeleton.bones[geometry.attributes.skinIndex.getComponent(id, k)].name;
        if (bone === `elbow_${side}` || bone === `wrist_${side}` || bone.startsWith(`forearm_twist_${side}_`)) weight += geometry.attributes.skinWeight.getComponent(id, k);
      }
      if (weight < 0.5) continue;
      point.fromBufferAttribute(position, id).applyMatrix4(toWrist);
      const along = point.dot(axis), radius = point.clone().addScaledVector(axis, -along).length();
      const amount = THREE.MathUtils.smoothstep(along, -0.3, -0.02);
      if (!amount || radius > 0.3) continue;
      point.addScaledVector(axis, -0.16 * amount).applyMatrix4(back);
      output.setXYZ(id, point.x, point.y, point.z);
      moved.add(id);
    }
  }
  fitted.computeVertexNormals();
  const normal = geometry.attributes.normal, changedNormals = new Set(moved), index = geometry.index;
  for (let i = 0; i < index.count; i += 3) {
    const face = [0, 1, 2].map((k) => index.getX(i + k));
    if (face.some((id) => moved.has(id))) face.forEach((id) => changedNormals.add(id));
  }
  const relative = geometry.morphTargetsRelative, shape = output.clone(), normals = normal.clone();
  for (let id = 0; id < position.count; id++) for (let k = 0; k < 3; k++) {
    shape.setComponent(id, k, output.getComponent(id, k) - (relative ? position.getComponent(id, k) : 0));
    normals.setComponent(id, k, (changedNormals.has(id) ? fitted.attributes.normal : normal).getComponent(id, k) - (relative ? normal.getComponent(id, k) : 0));
  }
  shape.name = normals.name = "construct-sleeve-ends";
  (geometry.morphAttributes.position ??= []).push(shape);
  (geometry.morphAttributes.normal ??= []).push(normals);
  fitted.dispose();
  const previous = mesh.morphTargetInfluences?.slice();
  mesh.geometry = geometry;
  mesh.updateMorphTargets();
  previous?.forEach((value, i) => {
    mesh.morphTargetInfluences[i] = value;
  });
  sleeves.set(rig, { mesh, index: mesh.morphTargetDictionary["construct-sleeve-ends"] });
  return geometry;
}
function poseConstructSleeves(rig, input) {
  const fitted = sleeves.get(rig);
  if (!fitted) return;
  fitted.mesh.morphTargetInfluences[fitted.index] = input.performance === "construct" || input.construct?.role === "neo" || input.reveal?.role === "neo" || input.truth?.role === "neo" && (input.truth.phase === "ready" || input.truth.phase === "exit") ? 1 : 0;
}
function feelingHand(rig, side, amount) {
  if (!amount) return;
  let hands = feeling.get(rig);
  if (!hands) feeling.set(rig, hands = /* @__PURE__ */ new Map());
  let target = hands.get(side);
  if (!target) {
    const skin = rig.root.getObjectByName("Anatomical_head_and_hands"), attributes = skin.geometry.attributes, sign = side === "R" ? 1 : -1;
    const tips = Array.from({ length: 5 }, () => new THREE.Vector3()), counts = [0, 0, 0, 0, 0], point = new THREE.Vector3();
    const distal = new Map(tips.map((_, digit) => [skin.skeleton.bones.indexOf(rig.bones.get(`finger${digit + 1}-3_${side}`)), digit]));
    for (let id = 0; id < attributes.position.count; id++) for (let k = 0; k < 4; k++) {
      if (attributes.skinWeight.getComponent(id, k) <= 0.95) continue;
      const joint = attributes.skinIndex.getComponent(id, k), digit = distal.get(joint);
      if (digit === void 0) continue;
      tips[digit].add(point.fromBufferAttribute(attributes.position, id).applyMatrix4(skin.bindMatrix).applyMatrix4(skin.skeleton.boneInverses[joint]));
      counts[digit]++;
      break;
    }
    target = [];
    for (let digit = 1; digit <= 5; digit++) {
      const names = [1, 2, 3].map((joint) => `finger${digit}-${joint}_${side}`), pad = tips[digit - 1].divideScalar(counts[digit - 1]);
      const axes = [rig.rest.get(names[1]), rig.rest.get(names[2]), pad], parent = new THREE.Quaternion();
      const thumbDirections = [[0.83, -0.5, 0.23], [0.65, -0.73, -0.21], [-0.1, -0.45, -0.88]];
      const joints = axes.map((axis, joint) => {
        const direction = digit === 1 ? new THREE.Vector3(sign * thumbDirections[joint][0], thumbDirections[joint][1], thumbDirections[joint][2]) : new THREE.Vector3(sign * [0.02, 0.06, 0.1][joint], -1, 0);
        const world = new THREE.Quaternion().setFromUnitVectors(axis.clone().normalize(), direction.normalize()), local = parent.clone().invert().multiply(world);
        parent.copy(world);
        return digit === 1 ? new THREE.Quaternion().slerp(local, 0.2 * 0.2) : local;
      });
      if (digit === 1) {
        joints[0].premultiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), -sign * 0.55 * Math.sin(Math.PI * 0.2)));
        joints[0].premultiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), sign * 0.14 * 0.2));
        joints[0].premultiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), -sign * 1.2));
      }
      target.push(...joints);
    }
    hands.set(side, target);
  }
  for (let digit = 1; digit <= 5; digit++) for (let joint = 1; joint <= 3; joint++)
    rig.bones.get(`finger${digit}-${joint}_${side}`).quaternion.slerp(target[(digit - 1) * 3 + joint - 1], amount);
  rig.bones.get(`wrist_${side}`).updateWorldMatrix(false, true);
}
function hand(rig, side, point, orientation, pole, amount) {
  if (!amount) return;
  const shoulder = rig.bones.get(`shoulder_${side}`), elbow = rig.bones.get(`elbow_${side}`), wrist = rig.bones.get(`wrist_${side}`);
  const before = wrist.quaternion.clone(), start = wrist.getWorldPosition(new THREE.Vector3());
  const pad = new THREE.Vector3(side === "R" ? 0.09 : -0.07, -0.18, 0);
  const goal = point.sub(pad.applyQuaternion(orientation)), target = start.clone().lerp(goal, amount);
  const arc = side === "L" ? new THREE.Vector3(0.2, 0, -0.6) : new THREE.Vector3(0, 0.35, 0.2);
  target.add(arc.applyQuaternion(rig.root.getWorldQuaternion(new THREE.Quaternion())).multiplyScalar(Math.sin(Math.PI * amount)));
  const origin = shoulder.getWorldPosition(new THREE.Vector3()), restDirection = start.sub(origin).normalize();
  const restPole = elbow.getWorldPosition(new THREE.Vector3()).sub(origin);
  restPole.addScaledVector(restDirection, -restPole.dot(restDirection)).normalize();
  const finalDirection = goal.clone().sub(origin).normalize(), direction = target.clone().sub(origin).normalize();
  pole.addScaledVector(finalDirection, -pole.dot(finalDirection)).normalize();
  const transported = restPole.clone().applyQuaternion(new THREE.Quaternion().setFromUnitVectors(restDirection, finalDirection));
  const roll = Math.atan2(finalDirection.dot(new THREE.Vector3().crossVectors(transported, pole)), transported.dot(pole));
  const bend = restPole.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(restDirection, direction)).applyAxisAngle(direction, roll * amount);
  reach(shoulder, elbow, wrist.position, target, bend);
  const local = elbow.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(orientation);
  wrist.quaternion.copy(before.slerp(local, THREE.MathUtils.smoothstep(amount, 0.55, 1)));
  const axis = wrist.position.clone().normalize(), q = wrist.quaternion, projection = q.x * axis.x + q.y * axis.y + q.z * axis.z;
  const twist = new THREE.Quaternion(axis.x * projection, axis.y * projection, axis.z * projection, q.w).normalize();
  const swing = q.clone().multiply(twist.clone().invert()), angle = swing.angleTo(new THREE.Quaternion());
  if (angle > Math.PI / 3) q.copy(new THREE.Quaternion().slerp(swing, Math.PI / 3 / angle)).multiply(twist);
  wrist.updateWorldMatrix(false, true);
}
function inspectConstructImage(rig, elapsed) {
  const smooth = THREE.MathUtils.smoothstep, forearm = smooth(elapsed, 0.3, 1) * (1 - smooth(elapsed, 2.1, 2.8));
  const neck = smooth(elapsed, 2.4, 3.6) * (1 - smooth(elapsed, 5, 6));
  rig.root.updateWorldMatrix(true, true);
  const root = rig.root.getWorldQuaternion(new THREE.Quaternion());
  feelingHand(rig, "R", forearm);
  feelingHand(rig, "L", neck);
  if (forearm) {
    const elbow = rig.bones.get("elbow_L").getWorldPosition(new THREE.Vector3()), wrist = rig.bones.get("wrist_L").getWorldPosition(new THREE.Vector3());
    const axis = wrist.clone().sub(elbow).normalize(), normal = new THREE.Vector3(0, 1, 0).applyQuaternion(root);
    normal.addScaledVector(axis, -normal.dot(axis)).normalize();
    const x = normal.clone().negate(), y = new THREE.Vector3(-1, 0, 0).applyQuaternion(root);
    y.addScaledVector(x, -y.dot(x)).normalize();
    const orientation = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(x, y, new THREE.Vector3().crossVectors(x, y)));
    hand(rig, "R", elbow.lerp(wrist, 0.7).addScaledVector(normal, 0.13), orientation, new THREE.Vector3(-0.8, -1, 0.6).applyQuaternion(root), forearm);
  }
  if (neck) {
    const head = rig.bones.get("head"), point = head.localToWorld(new THREE.Vector3(0, 0, -0.24)), angle = 25 * Math.PI / 180;
    const frame = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(
      new THREE.Vector3(0, 0, -1),
      new THREE.Vector3(Math.cos(angle), Math.sin(angle), 0),
      new THREE.Vector3(Math.sin(angle), -Math.cos(angle), 0)
    ));
    const orientation = head.getWorldQuaternion(new THREE.Quaternion()).multiply(frame);
    hand(rig, "L", point, orientation, new THREE.Vector3(1, 1, -0.2).applyQuaternion(root), neck);
  }
}
export {
  inspectConstructImage,
  poseConstructSleeves,
  prepareConstructSleeves
};
