import * as THREE from 'three';
import { actor } from './candidate-release/tests/helpers/fighting-hand-fixture.mjs';
import { handSurface } from './candidate-release/tests/helpers/hand-surface.mjs';
import { crossings } from './candidate-release/tests/helpers/hand-self-contact.mjs';
import { wristSwing } from './candidate-release/tests/helpers/core-connector.mjs';
import { advanceMotion,newMotion,type MotionInput } from './candidate-release/packages/client/src/agents/CharacterMotion.js';
const h=await actor('neo'),surfaces=['R','L'].map(side=>handSurface(h.rig,side)),handIds=new Set(surfaces.flatMap(s=>s.vertices));
let jump=0,at:unknown,last:THREE.Vector3[]|undefined;
for(let frame=0;frame<=600;frame++){
 const t=frame/100,input:MotionInput={speed:0,grounded:true,verticalVelocity:0,turn:0,construct:{role:'neo',phase:'image',elapsed:t}},motion=newMotion();
 h.models.animate(h.rig,advanceMotion(motion,input,0),motion,input,0);h.rig.root.updateMatrixWorld(true);
 const names=['elbow_R','wrist_R','elbow_L','wrist_L'],points=names.map(n=>h.rig.bones.get(n)!.getWorldPosition(new THREE.Vector3()));
 if(last)points.forEach((p,i)=>{const step=p.distanceTo(last![i]);if(step>jump){jump=step;at={t,joint:names[i]};}});last=points;
 if(![1,3.2,4].includes(t))continue;
 const bodyNames=['Anatomical_head_and_hands','Tailored_coat_upper','Black_crew_neck'],collisions=[];
 for(const [i,surface] of surfaces.entries()){
  const inverse=h.rig.bones.get(`wrist_${['R','L'][i]}`)!.matrixWorld.clone().invert(),draw=surface.draw(),box=new THREE.Box3().setFromPoints([...draw.points.values()]);
  for(const name of bodyNames){
   const mesh=h.rig.root.getObjectByName(name) as THREE.SkinnedMesh;if(!mesh.visible)continue;mesh.skeleton.update();
   const vertex=mesh.geometry.attributes.position,index=mesh.geometry.index!,matrix=inverse.clone().multiply(mesh.matrixWorld),posed=Array.from({length:vertex.count},(_,id)=>mesh.getVertexPosition(id,new THREE.Vector3()).applyMatrix4(matrix)),faces=[];
   for(let f=0;f<index.count;f+=3){const ids=[0,1,2].map(k=>index.getX(f+k));if(name==='Anatomical_head_and_hands'&&ids.some(id=>handIds.has(id)))continue;
    const points=ids.map(id=>posed[id]),bounds=new THREE.Box3().setFromPoints(points);if(!box.intersectsBox(bounds))continue;faces.push({face:f/3,ids,points,box:bounds});}
   const buckets=new Map<string,typeof faces>();
   for(const face of faces){const scores={R:0,L:0,other:0};for(const id of face.ids)for(let k=0;k<4;k++){const bone=mesh.skeleton.bones[mesh.geometry.attributes.skinIndex.getComponent(id,k)].name,key=/_R(?:_|$)/.test(bone)?'R':/_L(?:_|$)/.test(bone)?'L':'other';scores[key]+=mesh.geometry.attributes.skinWeight.getComponent(id,k);}const key=Object.entries(scores).sort((a,b)=>b[1]-a[1])[0][0];let group=buckets.get(key);if(!group)buckets.set(key,group=[]);group.push(face);}
   for(const [targetSide,group] of buckets){const result=crossings(draw.faces,group,false);if(result.count)collisions.push({side:['R','L'][i],name,targetSide,...result,where:result.examples.map(e=>{const handFace=draw.faces.find(f=>f.face===e.first)!;return handFace.points.reduce((sum,p)=>sum.add(p),new THREE.Vector3()).divideScalar(3).toArray();})});}
  }
 }
 console.log(JSON.stringify({t,swing:['R','L'].map(side=>wristSwing(h.rig.bones.get(`wrist_${side}`)!)),joints:Object.fromEntries(names.map((n,i)=>[n,points[i].toArray()])),collisions}));
}
console.log(JSON.stringify({jump,at}));h.models.dispose();
