import {readFile,writeFile,mkdir} from 'node:fs/promises';import {transformSync} from 'esbuild';import * as THREE from 'three';
import {constructInspection,inspectionPalm,inspectionBodyCrossings} from './candidate-release/tests/helpers/construct-inspection.mjs';import {handSurface} from './candidate-release/tests/helpers/hand-surface.mjs';
const h=await constructInspection();h.at(0);(h.models as unknown as {constructs:Map<unknown,{update:()=>void}>}).constructs.get(h.rig)!.update=()=>{};
const source=await readFile(new URL('./candidate-release/packages/client/src/agents/ConstructSelfImage.ts',import.meta.url),'utf8'),folder=new URL('./feeling-variants/',import.meta.url);await mkdir(folder,{recursive:true});const reach=new URL('./candidate-release/packages/client/src/agents/SpoonPerformance.ts',import.meta.url).href;
const added=`
const feelingTargets = new WeakMap<HeroRig, Map<string, THREE.Quaternion[]>>();
function feelingHand(rig:HeroRig, side:'R'|'L', amount:number, angle:number):void{
 if(!amount)return;let hands=feelingTargets.get(rig);if(!hands)feelingTargets.set(rig,hands=new Map());let target=hands.get(side);
 if(!target){
  const skin=rig.root.getObjectByName('Anatomical_head_and_hands') as THREE.SkinnedMesh,a=skin.geometry.attributes,sign=side==='R'?1:-1;target=[];
  for(let digit=1;digit<=5;digit++){
   const names=[1,2,3].map(j=>\`finger\${digit}-\${j}_\${side}\`),original=names.map(n=>rig.bones.get(n)!.quaternion.clone());
   if(digit===1){original[0].premultiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),-sign*angle));target.push(...original);continue;}
   const distal=skin.skeleton.bones.indexOf(rig.bones.get(names[2])!),pad=new THREE.Vector3();let count=0;
   for(let id=0;id<a.position.count;id++)if([0,1,2,3].some(k=>a.skinIndex.getComponent(id,k)===distal&&a.skinWeight.getComponent(id,k)>.95)){pad.add(new THREE.Vector3().fromBufferAttribute(a.position,id).applyMatrix4(skin.bindMatrix).applyMatrix4(skin.skeleton.boneInverses[distal]));count++;}
   pad.divideScalar(count);const axes=[rig.rest.get(names[1])!,rig.rest.get(names[2])!,pad],parent=new THREE.Quaternion();
   axes.forEach((axis,j)=>{const direction=new THREE.Vector3(sign*[.02,.06,.1][j],-1,0).normalize(),world=new THREE.Quaternion().setFromUnitVectors(axis.clone().normalize(),direction);target!.push(parent.clone().invert().multiply(world));parent.copy(world);});
  }
  hands.set(side,target);
 }
 for(let digit=1;digit<=5;digit++)for(let joint=1;joint<=3;joint++)rig.bones.get(\`finger\${digit}-\${joint}_\${side}\`)!.quaternion.slerp(target[(digit-1)*3+joint-1],amount);
 rig.root.updateWorldMatrix(true,true);
}
`;
for(const angle of [.4,.8,1.2])for(const pad of [.07,.09,.11,.13]){
 const edited=(source+added).replace("'./SpoonPerformance.js'",JSON.stringify(reach)).replace("side === 'R' ? .23 : -.23",`side === 'R' ? ${pad} : -${pad}`).replace('  if (forearm) {',`  feelingHand(rig,'R',forearm,${angle}); feelingHand(rig,'L',neck,${angle});\n  if (forearm) {`);
 const file=new URL(`feel-${angle}-${pad}.mjs`,folder);await writeFile(file,transformSync(edited,{loader:'ts',format:'esm',target:'es2022'}).code);const {inspectConstructImage}=await import(file.href);const rows=[];
 for(const [elapsed,side,name] of [[1.5,'R','Tailored_coat_upper'],[4,'L','Anatomical_head_and_hands']] as const){
  h.at(elapsed);inspectConstructImage(h.rig,elapsed);h.rig.root.updateMatrixWorld(true);const palm=inspectionPalm(h.rig,side),mesh=h.rig.root.getObjectByName(name) as THREE.SkinnedMesh;mesh.skeleton.update();mesh.computeBoundingSphere();
  const hits=new THREE.Raycaster(palm.world.clone().addScaledVector(palm.normal,-.3),palm.normal,0,.8).intersectObject(mesh,false),gap=hits[0]?.point.distanceTo(palm.world)??null;
  const collisions=inspectionBodyCrossings(h.rig),self=handSurface(h.rig,side).draw().self.count;
  rows.push({elapsed,side,gap,collisions:collisions.map((c:any)=>({side:c.side,name:c.name,count:c.count})),self});
 }
 console.log(JSON.stringify({angle,pad,rows}));
}
h.models.dispose();
