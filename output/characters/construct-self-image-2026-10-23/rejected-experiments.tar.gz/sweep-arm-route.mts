import { readFile,writeFile,mkdir } from 'node:fs/promises';
import { transformSync } from 'esbuild';
import * as THREE from 'three';
import {actor} from './candidate-release/tests/helpers/fighting-hand-fixture.mjs';
import {advanceMotion,newMotion,type MotionInput} from './candidate-release/packages/client/src/agents/CharacterMotion.js';
import {wristSwing} from './candidate-release/tests/helpers/core-connector.mjs';
const h=await actor('neo');
function base(elapsed:number){const input:MotionInput={speed:0,grounded:true,verticalVelocity:0,turn:0,clubClothes:true,glasses:false,performance:'construct',construct:{role:'neo',phase:'image',elapsed}},motion=newMotion();h.models.animate(h.rig,advanceMotion(motion,input,0),motion,input,0);h.rig.root.updateMatrixWorld(true);}
base(0);(h.models as unknown as {constructs:Map<unknown,{update:()=>void}>}).constructs.get(h.rig)!.update=()=>{};
const source=await readFile(new URL('./candidate-release/packages/client/src/agents/ConstructSelfImage.ts',import.meta.url),'utf8'),folder=new URL('./route-variants/',import.meta.url);await mkdir(folder,{recursive:true});
const reach=new URL('./candidate-release/packages/client/src/agents/SpoonPerformance.ts',import.meta.url).href;
for(const x of [.2,.4,.6,.8,1])for(const z of [-.1,-.3,-.5]){
 const edited=source.replace('new THREE.Vector3(.42, 0, -.23)',`new THREE.Vector3(${x}, 0, ${z})`).replace("'./SpoonPerformance.js'",JSON.stringify(reach));
 const file=new URL(`arc-${x}-${z}.mjs`,folder);await writeFile(file,transformSync(edited,{loader:'ts',format:'esm',target:'es2022'}).code);const {inspectConstructImage}=await import(file.href);
 let jump=0,at:unknown,maximum=0,last:THREE.Vector3[]|undefined;
 for(let i=0;i<=600;i++){
  const elapsed=i/100;base(elapsed);inspectConstructImage(h.rig,elapsed);h.rig.root.updateMatrixWorld(true);
  const names=['elbow_R','wrist_R','elbow_L','wrist_L'],points=names.map(n=>h.rig.bones.get(n)!.getWorldPosition(new THREE.Vector3()));
  if(last)points.forEach((p,j)=>{const step=p.distanceTo(last![j]);if(step>jump){jump=step;at={elapsed,joint:names[j]};}});last=points;
  maximum=Math.max(maximum,wristSwing(h.rig.bones.get('wrist_R')!),wristSwing(h.rig.bones.get('wrist_L')!));
 }
 console.log(JSON.stringify({x,z,jump,at,maximum}));
}
h.models.dispose();
