import * as THREE from 'three';
import {actor} from './candidate-release/tests/helpers/fighting-hand-fixture.mjs';
import {handSurface} from './candidate-release/tests/helpers/hand-surface.mjs';
import {wristSwing} from './candidate-release/tests/helpers/core-connector.mjs';
import {advanceMotion,newMotion,type MotionInput} from './candidate-release/packages/client/src/agents/CharacterMotion.js';
const h=await actor('neo'),s=handSurface(h.rig,'R');
let max=0,maxT=0,jump=0,last:THREE.Vector3[]|undefined;
for(let frame=0;frame<=600;frame++){
 const t=frame/100,input:MotionInput={speed:0,grounded:true,verticalVelocity:0,turn:0,construct:{role:'neo',phase:'image',elapsed:t}},motion=newMotion();
 h.models.animate(h.rig,advanceMotion(motion,input,0),motion,input,0);h.rig.root.updateMatrixWorld(true);
 const angle=wristSwing(h.rig.bones.get('wrist_R')!);if(angle>max){max=angle;maxT=t;}
 const points=['elbow_R','wrist_R'].map(n=>h.rig.bones.get(n)!.getWorldPosition(new THREE.Vector3()));
 if(last)points.forEach((p,i)=>{jump=Math.max(jump,p.distanceTo(last![i]));});last=points;
 if([0,.5,1,2,2.5,3,3.5,4,5,5.5,6].includes(t))console.log(JSON.stringify({t,angle,self:s.draw().self,...Object.fromEntries(['head','wrist_R','elbow_R','wrist_L'].map(n=>[n,h.rig.bones.get(n)!.getWorldPosition(new THREE.Vector3()).toArray()]))}));
}
console.log(JSON.stringify({maximumWristSwing:max,at:maxT,largestJointStepPer10ms:jump,vertices:s.vertices.length,triangles:s.triangles.length}));h.models.dispose();
