import * as THREE from "three";
import { reach } from "file:///Users/tianqizhong/ai_project/auto_matrix/output/characters/construct-self-image-2026-10-23/candidate-release/packages/client/src/agents/SpoonPerformance.ts";
function hand(rig, side, point, orientation, pole, amount) {
  if (!amount) return;
  const shoulder = rig.bones.get(`shoulder_${side}`), elbow = rig.bones.get(`elbow_${side}`), wrist = rig.bones.get(`wrist_${side}`);
  const before = wrist.quaternion.clone(), start = wrist.getWorldPosition(new THREE.Vector3());
  const pad = new THREE.Vector3(side === "R" ? 0.23 : -0.23, -0.18, 0);
  const goal = point.sub(pad.applyQuaternion(orientation)), target = start.clone().lerp(goal, amount);
  if (side === "L") target.add(new THREE.Vector3(0.4, 0, -0.3).applyQuaternion(rig.root.getWorldQuaternion(new THREE.Quaternion())).multiplyScalar(Math.sin(Math.PI * amount)));
  const origin = shoulder.getWorldPosition(new THREE.Vector3()), restDirection = start.sub(origin).normalize();
  const restPole = elbow.getWorldPosition(new THREE.Vector3()).sub(origin);
  restPole.addScaledVector(restDirection, -restPole.dot(restDirection)).normalize();
  const finalDirection = goal.clone().sub(origin).normalize(), direction = target.clone().sub(origin).normalize();
  pole.addScaledVector(finalDirection, -pole.dot(finalDirection)).normalize();
  const transported = restPole.clone().applyQuaternion(new THREE.Quaternion().setFromUnitVectors(restDirection, finalDirection));
  const roll = Math.atan2(finalDirection.dot(new THREE.Vector3().crossVectors(transported, pole)), transported.dot(pole));
  const bend = restPole.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(restDirection, direction)).applyAxisAngle(direction, roll * amount);
  reach(shoulder, elbow, wrist.position, target, bend);
  const local = elbow.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(orientation);
  wrist.quaternion.copy(before.slerp(local, THREE.MathUtils.smoothstep(amount, 0.55, 1)));
  const axis = wrist.position.clone().normalize(), q = wrist.quaternion, projection = q.x * axis.x + q.y * axis.y + q.z * axis.z;
  const twist = new THREE.Quaternion(axis.x * projection, axis.y * projection, axis.z * projection, q.w).normalize();
  const swing = q.clone().multiply(twist.clone().invert()), angle = swing.angleTo(new THREE.Quaternion());
  if (angle > Math.PI / 3) q.copy(new THREE.Quaternion().slerp(swing, Math.PI / 3 / angle)).multiply(twist);
  wrist.updateWorldMatrix(false, true);
}
function inspectConstructImage(rig, elapsed) {
  const smooth = THREE.MathUtils.smoothstep, forearm = smooth(elapsed, 0.3, 1) * (1 - smooth(elapsed, 2.1, 2.8));
  const neck = smooth(elapsed, 2.4, 3.6) * (1 - smooth(elapsed, 5, 6));
  rig.root.updateWorldMatrix(true, true);
  const root = rig.root.getWorldQuaternion(new THREE.Quaternion());
  if (forearm) {
    const elbow = rig.bones.get("elbow_L").getWorldPosition(new THREE.Vector3()), wrist = rig.bones.get("wrist_L").getWorldPosition(new THREE.Vector3());
    const axis = wrist.clone().sub(elbow).normalize(), normal = new THREE.Vector3(0, 1, 0).applyQuaternion(root);
    normal.addScaledVector(axis, -normal.dot(axis)).normalize();
    const x = normal.clone().negate(), y = new THREE.Vector3(-1, 0, 0).applyQuaternion(root);
    y.addScaledVector(x, -y.dot(x)).normalize();
    const orientation = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(x, y, new THREE.Vector3().crossVectors(x, y)));
    hand(rig, "R", elbow.lerp(wrist, 0.7).addScaledVector(normal, 0.13), orientation, new THREE.Vector3(-0.8, -1, 0.6).applyQuaternion(root), forearm);
  }
  if (neck) {
    const head = rig.bones.get("head"), point = head.localToWorld(new THREE.Vector3(0, -0.08, -0.23)), angle = 10 * Math.PI / 180;
    const frame = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(
      new THREE.Vector3(0, 0, -1),
      new THREE.Vector3(Math.cos(angle), Math.sin(angle), 0),
      new THREE.Vector3(Math.sin(angle), -Math.cos(angle), 0)
    ));
    const orientation = head.getWorldQuaternion(new THREE.Quaternion()).multiply(frame);
    hand(rig, "L", point, orientation, new THREE.Vector3(1, 1, -0.2).applyQuaternion(root), neck);
  }
}
export {
  inspectConstructImage
};
