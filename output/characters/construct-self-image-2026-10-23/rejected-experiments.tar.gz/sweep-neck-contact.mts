import {readFile,writeFile,mkdir} from 'node:fs/promises';import * as THREE from 'three';
import {constructInspection,inspectionPalm,inspectionBodyCrossings} from './candidate-release/tests/helpers/construct-inspection.mjs';import {handSurface} from './candidate-release/tests/helpers/hand-surface.mjs';import {wristSwing} from './candidate-release/tests/helpers/core-connector.mjs';
const h=await constructInspection();h.at(0);(h.models as unknown as {constructs:Map<unknown,{update:()=>void}>}).constructs.get(h.rig)!.update=()=>{};
const base=await readFile(new URL('./feeling-variants/feel-1.2-0.09.mjs',import.meta.url),'utf8'),folder=new URL('./neck-variants/',import.meta.url);await mkdir(folder,{recursive:true});
for(const angle of [25,40,55])for(const y of [0,-.06,-.12])for(const z of [-.17,-.19,-.21]){
 const edited=base.replace('side === "R" ? 0.09 : -0.09','side === "R" ? 0.09 : -0.07').replace('new THREE.Vector3(0, -0.08, -0.23)',`new THREE.Vector3(0, ${y}, ${z})`).replace('angle = 10 * Math.PI / 180',`angle = ${angle} * Math.PI / 180`);
 const file=new URL(`neck-${angle}-${y}-${z}.mjs`,folder);await writeFile(file,edited);const {inspectConstructImage}=await import(file.href);h.at(4);inspectConstructImage(h.rig,4);h.rig.root.updateMatrixWorld(true);
 const palm=inspectionPalm(h.rig,'L'),skin=h.rig.root.getObjectByName('Anatomical_head_and_hands') as THREE.SkinnedMesh;skin.skeleton.update();skin.computeBoundingSphere();
 const hit=new THREE.Raycaster(palm.world.clone().addScaledVector(palm.normal,-.3),palm.normal,0,.8).intersectObject(skin,false).find(hit=>[hit.face!.a,hit.face!.b,hit.face!.c].reduce((sum,id)=>sum+[0,1,2,3].reduce((s,k)=>s+(skin.skeleton.bones[skin.geometry.attributes.skinIndex.getComponent(id,k)].name==='head'?skin.geometry.attributes.skinWeight.getComponent(id,k):0),0),0)>1.5);
 const collisions=inspectionBodyCrossings(h.rig),self=handSurface(h.rig,'L').draw().self.count;
 console.log(JSON.stringify({angle,y,z,gap:hit?.point.distanceTo(palm.world)??null,collisions:collisions.map((c:any)=>({side:c.side,name:c.name,count:c.count})),self,wristSwing:wristSwing(h.rig.bones.get('wrist_L')!)}));
}
h.models.dispose();
