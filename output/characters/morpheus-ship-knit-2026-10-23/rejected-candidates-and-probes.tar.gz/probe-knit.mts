import * as THREE from 'three';
import { actor } from './baseline-release/tests/helpers/fighting-hand-fixture.mjs';
const h=await actor('morpheus');
try {
 const garment=h.rig.root.getObjectByName('morpheus-hammer-sweater')as THREE.SkinnedMesh;
 const a=garment.geometry.attributes;
 const mesh=new THREE.Mesh(garment.geometry,new THREE.MeshBasicMaterial({side:THREE.DoubleSide}));mesh.updateMatrixWorld(true);
 const rows=[];
 for(const y of [2.4,2.6,2.8,3,3.15,3.3,3.45,3.6,3.75]){
  const row=[];for(const x of [-.5,-.4,-.3,-.2,-.1,0,.1,.2,.3,.4,.5]){
   const hit=new THREE.Raycaster(new THREE.Vector3(x,y,2),new THREE.Vector3(0,0,-1),0,4).intersectObject(mesh)[0];row.push(hit?.point.z??null);
  }rows.push({y,z:row});
 }
 console.log(JSON.stringify({mesh:garment.name,vertices:a.position.count,triangles:garment.geometry.index!.count/3,rows}));
 for(const part of h.rig.wardrobe) if(part.mesh instanceof THREE.SkinnedMesh) console.log(JSON.stringify({name:part.mesh.name,vertices:part.mesh.geometry.attributes.position.count,triangles:part.mesh.geometry.index?.count,visible:part.mesh.visible}));
 mesh.material.dispose();
}finally{h.models.dispose();}
