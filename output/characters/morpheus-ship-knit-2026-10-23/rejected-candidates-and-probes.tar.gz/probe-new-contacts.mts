import { shipKnit } from './candidate-release/tests/helpers/ship-knit.mjs';
const h=await shipKnit();try{
 h.pose({seated:true,truth:{role:'morpheus',phase:'rest',elapsed:0}});
 const fitted=h.sweater.geometry,actual=h.contacts();h.sweater.geometry=h.original;const before=h.contacts();
 const lookup=new Map(before.self.pairs.map(p=>[`${p.first}/${p.second}`,p.line]));
 const fresh=actual.self.pairs.filter(p=>p.line>(lookup.get(`${p.first}/${p.second}`)??0)+1e-7);
 const a=h.original.attributes,index=h.original.index!;
 console.log(JSON.stringify({count:fresh.length,faces:fresh.slice(0,20).map(p=>({...p,before:lookup.get(`${p.first}/${p.second}`),vertices:[p.first,p.second].map(f=>[0,1,2].map(k=>{const i=index.getX(f*3+k);return{x:a.position.getX(i),y:a.position.getY(i),z:a.position.getZ(i),moved:fitted.attributes.position.getZ(i)-a.position.getZ(i)}}))}))}));
}finally{h.dispose()}
