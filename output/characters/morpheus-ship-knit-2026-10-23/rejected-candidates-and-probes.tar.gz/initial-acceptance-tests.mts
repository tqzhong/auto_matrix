import assert from 'node:assert/strict';
import test from 'node:test';
import * as THREE from 'three';
import { newMotion } from '../packages/client/src/agents/CharacterMotion.js';
import { shipKnit } from './helpers/ship-knit.mjs';

test('Morpheus ship knit bridges the chest instead of preserving two anatomical pectoral lobes', async t => {
  const h = await shipKnit(t); h.pose();
  const material = new THREE.MeshBasicMaterial({ side: THREE.DoubleSide }); t.after(() => material.dispose());
  const shell = new THREE.Mesh(h.sweater.geometry, material); shell.updateMatrixWorld(true);
  const front = (x: number, y: number) => {
    const hit = new THREE.Raycaster(new THREE.Vector3(x, y, 2), new THREE.Vector3(0, 0, -1), 0, 3).intersectObject(shell)[0];
    assert.ok(hit, `the original closed chest must remain at ${x},${y}`); return hit.point.z;
  };
  const rows = [3.2, 3.3, 3.4, 3.45].map(y => ({ y, valley: (front(-.18, y) + front(.18, y)) / 2 - front(0, y) }));
  t.diagnostic(JSON.stringify(rows));
  assert.ok(rows.every(row => row.valley < .006), 'the knitted torso still traces the anatomical chest cleft');
});

test('ship fitting leaves all original faces, UVs and weights intact and restores the donor used by other costumes', async t => {
  const h = await shipKnit(t), original = h.original;
  const source = Object.fromEntries(Object.entries(original.attributes).map(([key, a]) => [key, Array.from(a.array)]));
  const others = h.rig.wardrobe.filter(p => /ambush|construct|Tailored.coat.upper|Black.crew.neck/.test(p.mesh.name)).map(p => ({ mesh: p.mesh, geometry: p.mesh.geometry, data: Array.from(p.mesh.geometry.attributes.position.array) }));
  h.pose();
  assert.deepEqual(Array.from(h.sweater.geometry.index!.array), Array.from(original.index!.array));
  for (const key of ['uv', 'skinIndex', 'skinWeight']) assert.deepEqual(Array.from(h.sweater.geometry.attributes[key].array), source[key]);
  h.pose({ realWorld: false, nebCrew: undefined, nebCrewEarly: false });
  assert.equal(h.sweater.geometry, original);
  assert.deepEqual(Object.fromEntries(Object.entries(original.attributes).map(([key, a]) => [key, Array.from(a.array)])), source);
  for (const other of others) { assert.equal(other.mesh.geometry, other.geometry); assert.deepEqual(Array.from(other.mesh.geometry.attributes.position.array), other.data); }
});

test('the full ship sweater clears itself and visible skin, hands, collar and trousers in seated and standing dialogue', async t => {
  const h = await shipKnit(t);
  for (const elapsed of [0, 6, 8, 12, 17]) {
    h.pose({ seated: true, truth: { role: 'morpheus', phase: 'rest', elapsed } });
    const result = h.contacts(); t.diagnostic(JSON.stringify({ elapsed, ...result }));
    assert.equal(result.self.count, 0, `${elapsed}: complete knit self intersection`);
    assert.deepEqual(result.bodies, [], `${elapsed}: complete knit and visible body intersection`);
  }
  h.pose(); const result = h.contacts(); assert.equal(result.self.count, 0); assert.deepEqual(result.bodies, []);
});

test('cold and paused ship costumes retain the same complete surface as continuous dialogue animation', async t => {
  const warm = await shipKnit(t), cold = await shipKnit(t), motion = newMotion();
  for (let frame = 0; frame <= 1080; frame++) {
    const input = { seated: true, truth: { role: 'morpheus' as const, phase: 'rest' as const, elapsed: frame / 60 } };
    warm.pose(input, motion, 1 / 60);
    if (![0, 180, 360, 540, 720, 1080].includes(frame)) continue;
    cold.pose(input);
    const a = warm.faceSurface(warm.sweater).points, b = cold.faceSurface(cold.sweater).points;
    assert.ok(a.every((p, i) => p.distanceTo(b[i]) < 1e-7), `${frame}: cold surface differs`);
    const geometry = cold.sweater.geometry, version = geometry.attributes.position.version;
    cold.pose(input, newMotion(), .5);
    assert.equal(cold.sweater.geometry, geometry); assert.equal(geometry.attributes.position.version, version);
    assert.ok(cold.faceSurface(cold.sweater).points.every((p, i) => p.distanceTo(b[i]) < 1e-7), `${frame}: paused surface drift`);
  }
});
