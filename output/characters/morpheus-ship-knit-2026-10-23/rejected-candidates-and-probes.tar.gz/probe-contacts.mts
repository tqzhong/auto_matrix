import * as THREE from 'three';
import { shipKnit } from './candidate-release/tests/helpers/ship-knit.mjs';
const h = await shipKnit();
try {
 for (const seated of [false,true]) {
  h.pose(seated?{seated:true,truth:{role:'morpheus',phase:'rest',elapsed:0}}:{});
  const result = h.contacts();
  const detail = (face:number) => {
   const a=h.sweater.geometry.attributes,index=h.sweater.geometry.index!;
   return [0,1,2].map(k=>{const id=index.getX(face*3+k);return {id,p:[a.position.getX(id),a.position.getY(id),a.position.getZ(id)],uv:[a.uv.getX(id),a.uv.getY(id)],w:[0,1,2,3].map(j=>[h.sweater.skeleton.bones[a.skinIndex.getComponent(id,j)].name,a.skinWeight.getComponent(id,j)])}});
  };
  console.log(JSON.stringify({seated,...result,details:result.self.examples.map((e:any)=>({a:detail(e.first),b:detail(e.second)}))}));
 }
}finally{h.dispose();}
