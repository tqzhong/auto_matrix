import * as THREE from 'three';

/** Fit the ship knit once; its original surface remains the donor for the other costumes. */
export function fitShipKnit(mesh: THREE.SkinnedMesh, trousers: THREE.SkinnedMesh): THREE.BufferGeometry {
  const geometry = mesh.geometry.clone(), a = geometry.attributes, index = geometry.index!;
  const points = Array.from({ length: a.position.count }, (_, i) => new THREE.Vector3().fromBufferAttribute(a.position, i));
  const uv = (i: number) => new THREE.Vector2(a.uv.getX(i), a.uv.getY(i));
  const bands = (positions: THREE.Vector3[], faces: THREE.BufferAttribute) => {
    const rows = new Map<number, number[]>();
    for (let i = 0; i < faces.count; i += 3) {
      const heights = [0, 1, 2].map(k => positions[faces.getX(i + k)].y);
      for (let row = Math.floor(Math.min(...heights) * 20); row <= Math.floor(Math.max(...heights) * 20); row++) {
        let list = rows.get(row); if (!list) rows.set(row, list = []); list.push(i);
      }
    }
    return (y: number) => rows.get(Math.floor(y * 20)) ?? [];
  };
  const band = bands(points, index);
  // Mirrored donor folds cross their centre seam. Recover lateral spacing
  // from the intact UV panels instead of deleting the overlapping triangles.
  const seam = (side: number, front: boolean) => points.flatMap((p, id) => {
    if (Math.abs(p.x) > 1e-6 || (front ? p.z <= .1 || p.y <= 2.6 || p.y >= 2.95 : p.z >= -.1 || p.y <= 2.37 || p.y >= 2.75 || (uv(id).x < .38 ? -1 : 1) !== side)) return [];
    const x = side * .1, y = p.y;
    let depth = front ? -Infinity : Infinity, edge = uv(id).x;
    for (const i of band(y)) {
      const ids = [0, 1, 2].map(k => index.getX(i + k)), [a, b, c] = ids.map(id => points[id]);
      const d = (b.y - c.y) * (a.x - c.x) + (c.x - b.x) * (a.y - c.y);
      if (Math.abs(d) < 1e-9) continue;
      const u = ((b.y - c.y) * (x - c.x) + (c.x - b.x) * (y - c.y)) / d;
      const v = ((c.y - a.y) * (x - c.x) + (a.x - c.x) * (y - c.y)) / d, w = 1 - u - v;
      if (Math.min(u, v, w) < -1e-6) continue;
      const z = u * a.z + v * b.z + w * c.z;
      if (front ? z > depth : z < depth) { depth = z; edge = u * uv(ids[0]).x + v * uv(ids[1]).x + w * uv(ids[2]).x; }
    }
    return [{ u: uv(id).x, v: uv(id).y, scale: .1 / Math.abs(edge - uv(id).x) }];
  }).sort((a, b) => a.v - b.v);
  const back = [-1, 1].map(side => seam(side, false)), front = seam(1, true);
  const row = (seam: typeof front, v: number) => {
    const end = seam.findIndex(p => p.v >= v);
    if (end <= 0) return seam[end < 0 ? seam.length - 1 : 0];
    const a = seam[end - 1], b = seam[end], t = (v - a.v) / (b.v - a.v);
    return { u: THREE.MathUtils.lerp(a.u, b.u, t), v, scale: THREE.MathUtils.lerp(a.scale, b.scale, t) };
  };
  const returns = new Map<number, { outer: number; thickness: number }>();
  for (let i = 0; i < index.count; i += 3) for (let k = 0; k < 3; k++) {
    const a = index.getX(i + k), b = index.getX(i + (k + 1) % 3);
    const outer = points[a].y < points[b].y ? a : b, inner = outer === a ? b : a;
    if (Math.abs(points[outer].y - 2.38) < 1e-6 && uv(outer).distanceTo(uv(inner)) < 1e-7)
      returns.set(inner, { outer, thickness: points[inner].distanceTo(points[outer]) });
  }
  const fitted = points.map(p => p.clone());
  for (let i = 0; i < points.length; i++) {
    const p = points[i];
    if (Math.abs(p.x) < .1 && p.z > .1 && p.y > 2.65 && p.y < 2.9) {
      const centre = row(front, uv(i).y), amount = (1 - THREE.MathUtils.smoothstep(Math.abs(p.x), .04, .1))
        * THREE.MathUtils.smoothstep(p.y, 2.65, 2.72) * (1 - THREE.MathUtils.smoothstep(p.y, 2.83, 2.9));
      fitted[i].x = THREE.MathUtils.lerp(p.x, (uv(i).x - centre.u) * centre.scale, amount);
    }
    if (Math.abs(p.x) < .1 && p.z < -.1 && p.y < 2.7) {
      const side = uv(i).x < .38 ? -1 : 1, centre = row(back[side < 0 ? 0 : 1], uv(i).y);
      const amount = (1 - THREE.MathUtils.smoothstep(Math.abs(p.x), .04, .1)) * (1 - THREE.MathUtils.smoothstep(p.y, 2.566, 2.7));
      fitted[i].x = THREE.MathUtils.lerp(p.x, side * Math.max(0, -side * (uv(i).x - centre.u)) * centre.scale, amount);
    }
    const torso = [0, 1, 2, 3].reduce((sum, k) => sum + (/^(pelvis|spine|chest)$/.test(mesh.skeleton.bones[a.skinIndex.getComponent(i, k)].name) ? a.skinWeight.getComponent(i, k) : 0), 0);
    const drape = THREE.MathUtils.smoothstep(torso, .65, .98) * THREE.MathUtils.smoothstep(p.y, 2.48, 2.7)
      * (1 - THREE.MathUtils.smoothstep(p.y, 3.48, 3.73)) * THREE.MathUtils.smoothstep(p.z, .06, .25);
    const chest = .50 * Math.sqrt(Math.max(0, 1 - (p.x / .72) ** 2));
    fitted[i].z += Math.max(0, chest - p.z) * drape;
  }
  const pants = Array.from({ length: trousers.geometry.attributes.position.count }, (_, i) => new THREE.Vector3().fromBufferAttribute(trousers.geometry.attributes.position, i));
  const pantsIndex = trousers.geometry.index!, pantsBand = bands(pants, pantsIndex), ray = new THREE.Ray(), hit = new THREE.Vector3();
  const beforeWaist = fitted.map(p => p.clone());
  const waist = points.map((_, i) => [0, 1, 2, 3].reduce((sum, k) => sum + (/^(pelvis|spine|chest|hip_[LR])$/.test(mesh.skeleton.bones[a.skinIndex.getComponent(i, k)].name) ? a.skinWeight.getComponent(i, k) : 0), 0));
  for (let i = 0; i < fitted.length; i++) {
    const p = fitted[i]; if (p.y >= 2.85 || waist[i] <= .8) continue;
    ray.origin.set(0, p.y, 0); ray.direction.set(p.x, 0, p.z).normalize();
    let required = 0, radius = Math.hypot(p.x, p.z), inner = radius;
    for (const f of pantsBand(p.y)) {
      if (ray.intersectTriangle(pants[pantsIndex.getX(f)], pants[pantsIndex.getX(f + 1)], pants[pantsIndex.getX(f + 2)], false, hit)) required = Math.max(required, hit.distanceTo(ray.origin) + .035);
    }
    for (const f of band(p.y)) {
      if ([0, 1, 2].some(k => waist[index.getX(f + k)] <= .8)) continue;
      if (ray.intersectTriangle(beforeWaist[index.getX(f)], beforeWaist[index.getX(f + 1)], beforeWaist[index.getX(f + 2)], false, hit)) inner = Math.min(inner, hit.distanceTo(ray.origin));
    }
    radius += Math.max(0, required - inner); p.x = ray.direction.x * radius; p.z = ray.direction.z * radius;
  }
  const normals = new Map<number, THREE.Vector3>();
  for (const { outer } of returns.values()) normals.set(outer, new THREE.Vector3());
  for (let i = 0; i < index.count; i += 3) {
    const ids = [0, 1, 2].map(k => index.getX(i + k));
    if (ids.some(id => returns.has(id)) || !ids.some(id => normals.has(id))) continue;
    const n = new THREE.Vector3().subVectors(fitted[ids[1]], fitted[ids[0]]).cross(new THREE.Vector3().subVectors(fitted[ids[2]], fitted[ids[0]]));
    for (const id of ids) normals.get(id)?.add(n);
  }
  for (const [inner, { outer, thickness }] of returns) fitted[inner].copy(fitted[outer]).addScaledVector(normals.get(outer)!.normalize(), -thickness);
  fitted.forEach((p, i) => a.position.setXYZ(i, p.x, p.y, p.z));
  geometry.computeVertexNormals();
  // UV twins must shade as a sewn surface, including the newly unfolded hem.
  const smooth = new Map<string, THREE.Vector3>();
  const key = (i: number) => fitted[i].toArray().map(n => n.toFixed(6)).join(',');
  fitted.forEach((_, i) => { let normal = smooth.get(key(i)); if (!normal) smooth.set(key(i), normal = new THREE.Vector3()); normal.add(new THREE.Vector3().fromBufferAttribute(a.normal, i)); });
  fitted.forEach((_, i) => { const n = smooth.get(key(i))!.clone().normalize(); a.normal.setXYZ(i, n.x, n.y, n.z); });
  geometry.computeBoundingBox(); geometry.computeBoundingSphere();
  return geometry;
}
