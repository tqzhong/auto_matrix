import * as THREE from 'three';
import { shipKnit } from './candidate-release/tests/helpers/ship-knit.mjs';
const h=await shipKnit();h.pose();try{
 const m=new THREE.Mesh(h.sweater.geometry,new THREE.MeshBasicMaterial({side:THREE.DoubleSide}));m.updateMatrixWorld(true);
 for(const y of [2.9,3,3.1,3.2,3.3,3.4,3.5,3.6]) console.log(JSON.stringify({y,hits:[-.3,-.15,0,.15,.3].map(x=>{const p=new THREE.Raycaster(new THREE.Vector3(x,y,2),new THREE.Vector3(0,0,-1),0,3).intersectObject(m)[0];return p&&{x,z:p.point.z,uv:p.uv?.toArray(),n:p.normal?.toArray()}})}));
 console.log(JSON.stringify({morph:h.sweater.morphTargetInfluences,material:(h.sweater.material as THREE.MeshStandardMaterial).toJSON()}));
}finally{h.dispose()}
