import * as THREE from 'three';
import { desertGuide } from './candidate-release/tests/helpers/desert-guide.mjs';
import { ConstructPerformance } from './candidate-release/packages/client/src/agents/ConstructPerformance.js';
import { supportedHand } from './candidate-release/packages/client/src/agents/ConstructChairContact.js';
import { wristSwing } from './candidate-release/tests/helpers/core-connector.mjs';

let pole = new THREE.Vector3(-1,-1,1);
const original=ConstructPerformance.prototype.update;
ConstructPerformance.prototype.update=function(input){
 original.call(this,{...input,reveal:input.reveal?{...input.reveal,kind:'construct'}:undefined});
 if(input.reveal?.kind!=='desert')return;
 (this as any).seatedFeet();
 supportedHand((this as any).rig,'L',(this as any).rig.root.localToWorld(new THREE.Vector3(1.6,3.04,1).multiplyScalar(.65)),new THREE.Vector3(0,-1,0),1,pole);
 const elapsed=input.reveal.elapsed,amount=THREE.MathUtils.smoothstep(elapsed,1.3,2.8)*(1-THREE.MathUtils.smoothstep(elapsed,9.5,11.2));
 (this as any).raiseRemote(amount,true);
};
const h=await desertGuide();
try{
 for(const values of [[-1,-1,1],[-1.1,-1,1],[-1,-1.1,1],[-1,-1,.9],[-1.1,-1.1,1],[-1.2,-1,1],[-1,-1.2,1]]){
  pole.fromArray(values);
  for(const elapsed of [0,3.5]){
   h.at(elapsed);const sleeves=h.sleeves();
   const result:any={pole:values,elapsed,sleeves,wrist:wristSwing(h.rig.bones.get('wrist_L')!)};
   if(sleeves.every(s=>s.self===0&&s.shirt===0&&s.chair===0)){result.hands=h.hands();result.body=h.body();}
   console.log(JSON.stringify(result));
  }
 }
}finally{h.dispose();ConstructPerformance.prototype.update=original;}
