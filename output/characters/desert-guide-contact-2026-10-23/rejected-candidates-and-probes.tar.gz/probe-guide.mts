import * as THREE from 'three';
import { desertGuide } from './baseline-release/tests/helpers/desert-guide.mjs';
import { wristSwing } from './baseline-release/tests/helpers/core-connector.mjs';
const h=await desertGuide();
for(const elapsed of [0,1,3,6,9,11,13]){h.at(elapsed);console.log(JSON.stringify({elapsed,wrists:['R','L'].map(s=>wristSwing(h.rig.bones.get(`wrist_${s}`)!)),hands:h.hands()}));}
const meshes=[];h.rig.root.traverse(o=>{if(o instanceof THREE.Mesh&&o.visible)meshes.push({name:o.name,skin:o instanceof THREE.SkinnedMesh,vertices:o.geometry.attributes.position.count});});console.log(JSON.stringify({meshes}));h.dispose();
