import * as THREE from 'three';
import { desertGuide } from './candidate-release/tests/helpers/desert-guide.mjs';
import { ConstructPerformance } from './candidate-release/packages/client/src/agents/ConstructPerformance.js';
import { supportedHand } from './candidate-release/packages/client/src/agents/ConstructChairContact.js';
import { wristSwing } from './candidate-release/tests/helpers/core-connector.mjs';
const original=ConstructPerformance.prototype.update;ConstructPerformance.prototype.update=function(input){original.call(this,{...input,reveal:input.reveal?{...input.reveal,kind:'construct'}:undefined});if(input.reveal?.kind==='desert')(this as any).seatedFeet();};
const h=await desertGuide();try{for(const x of [-1,0,1])for(const y of [-1,-.3])for(const z of [.3,1]){h.at(3);supportedHand(h.rig,'L',h.rig.root.localToWorld(new THREE.Vector3(1.6,3.04,1).multiplyScalar(.65)),new THREE.Vector3(0,-1,0),1,new THREE.Vector3(x,y,z));const hand=h.hands()[1],body=h.body().filter(e=>e.side==='L');console.log(JSON.stringify({pole:[x,y,z],hand,body:body.map(e=>({mesh:e.mesh,count:e.count})),wrist:wristSwing(h.rig.bones.get('wrist_L')!)}));}}finally{h.dispose();ConstructPerformance.prototype.update=original;}
