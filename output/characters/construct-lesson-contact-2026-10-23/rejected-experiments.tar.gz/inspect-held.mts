import * as THREE from 'three';
import {constructLesson} from './candidate-release/tests/helpers/construct-lesson.mjs';
import {inspectionPalm} from './candidate-release/tests/helpers/construct-inspection.mjs';
import {fingerGroups} from './candidate-release/tests/helpers/fighting-hand-fixture.mjs';
const h=await constructLesson('neo');h.at(3);
for(const side of ['R','L'] as const){const wrist=h.rig.bones.get('wrist_'+side)!,palm=inspectionPalm(h.rig,side),groups=fingerGroups(h.rig,side);groups.skin.skeleton.update();
const report=(p:THREE.Vector3)=>{const hit=new THREE.Raycaster(p.clone().add(new THREE.Vector3(0,.8,0)),new THREE.Vector3(0,-1,0),0,2).intersectObject(h.chair)[0];return{chairLocal:h.chair.worldToLocal(p.clone()).toArray(),gap:hit?hit.distance-.8:null};};
console.log(JSON.stringify({side,palm:report(palm.world),palmNormal:palm.normal.toArray(),fingersDirection:new THREE.Vector3(0,-1,0).transformDirection(wrist.matrixWorld).toArray(),tips:groups.tips.map(ids=>report(ids.reduce((sum,id)=>sum.add(groups.skin.localToWorld(groups.skin.getVertexPosition(id,new THREE.Vector3()))),new THREE.Vector3()).divideScalar(ids.length)))}));}h.dispose();
