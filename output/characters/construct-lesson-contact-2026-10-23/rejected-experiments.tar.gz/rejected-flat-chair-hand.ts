import * as THREE from 'three';
import { CONSTRUCT,FILM_SETS } from '@auto_matrix/shared';
import type { HeroRig } from './HeroModel.js';
import { reach } from './SpoonPerformance.js';

const fingers = new WeakMap<HeroRig,Map<string,THREE.Quaternion[]>>();
function frame(direction:THREE.Vector3,normal:THREE.Vector3):THREE.Quaternion {
 const y=direction.clone().normalize(),z=normal.clone().addScaledVector(y,-normal.dot(y)).normalize();
 return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3().crossVectors(y,z),y,z));
}
function supportedHand(rig:HeroRig,side:'R'|'L',point:THREE.Vector3,amount:number):void {
 const shoulder=rig.bones.get(`shoulder_${side}`)!,elbow=rig.bones.get(`elbow_${side}`)!,wrist=rig.bones.get(`wrist_${side}`)!,sign=side==='R'?1:-1;
 const before=[shoulder.quaternion.clone(),elbow.quaternion.clone(),wrist.quaternion.clone()];
 const offset=new THREE.Vector3(sign*.05,-.191,.001),orientation=new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3(0,-sign,0),new THREE.Vector3(0,0,1),new THREE.Vector3(-sign,0,0)));
 const pole=new THREE.Vector3(0,-.5,1);
 const solve=(contact:THREE.Vector3)=>{
  const goal=contact.clone().sub(offset.clone().applyQuaternion(orientation));
  reach(shoulder,elbow,wrist.position,goal,pole.clone());
  wrist.quaternion.copy(elbow.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(orientation));wrist.updateWorldMatrix(false,true);
  return [shoulder.quaternion.clone(),elbow.quaternion.clone(),wrist.quaternion.clone()];
 };
 const final=solve(point),stage=solve(point.clone().add(new THREE.Vector3(0,.4,.3)));
 const enter=THREE.MathUtils.smoothstep(amount,0,.6),settle=THREE.MathUtils.smoothstep(amount,.6,1);
 for(const [i,joint] of [shoulder,elbow,wrist].entries())joint.quaternion.copy(before[i]).slerp(stage[i],enter).slerp(final[i],settle);
 shoulder.updateWorldMatrix(true,true);
 let hands=fingers.get(rig);if(!hands)fingers.set(rig,hands=new Map());let targets=hands.get(side);
 if(!targets){
  targets=[];
  const skin=rig.root.getObjectByName('Anatomical_head_and_hands') as THREE.SkinnedMesh,a=skin.geometry.attributes;
  for(let digit=2;digit<=5;digit++){
   const distal=skin.skeleton.bones.indexOf(rig.bones.get(`finger${digit}-3_${side}`)!),tip=new THREE.Vector3();let count=0;
   for(let id=0;id<a.position.count;id++)for(let k=0;k<4;k++)if(a.skinIndex.getComponent(id,k)===distal&&a.skinWeight.getComponent(id,k)>.95){tip.add(new THREE.Vector3().fromBufferAttribute(a.position,id).applyMatrix4(skin.bindMatrix).applyMatrix4(skin.skeleton.boneInverses[distal]));count++;break;}
   const axes=[rig.rest.get(`finger${digit}-2_${side}`)!,rig.rest.get(`finger${digit}-3_${side}`)!,tip.divideScalar(count)],parent=new THREE.Quaternion();
   axes.forEach((axis,j)=>{const world=new THREE.Quaternion().setFromUnitVectors(axis.clone().normalize(),new THREE.Vector3(sign*[.05,.25,.45][j],-1,0).normalize());targets!.push(parent.clone().invert().multiply(world));parent.copy(world);});
  }
  hands.set(side,targets);
 }
 for(let digit=2;digit<=5;digit++)for(let joint=1;joint<=3;joint++)rig.bones.get(`finger${digit}-${joint}_${side}`)!.quaternion.slerp(targets[(digit-2)*3+joint-1],amount);
 wrist.updateWorldMatrix(false,true);
}

/** Both real palms settle onto the crown before the fingers curl over its front. */
export function touchConstructChair(rig:HeroRig,elapsed:number):void {
 const amount=THREE.MathUtils.smoothstep(elapsed,.15,1.65)*(1-THREE.MathUtils.smoothstep(elapsed,6.5,8));if(!amount)return;
 rig.root.updateWorldMatrix(true,true);const center=FILM_SETS.film_white_construct.center,scale=CONSTRUCT.chair.scale;
 for(const [side,u] of [['L',.4],['R',.96]] as const){
  const x=CONSTRUCT.chairX.neo+u*(1.56+.22*Math.sin(Math.PI*.85))*scale,y=(1.45+3.5+.4*(1-u*u))*scale;
  const z=CONSTRUCT.chair.z+(.94+.55-.62*u**4*Math.sin(Math.PI*.9))*scale;
  supportedHand(rig,side,new THREE.Vector3(center.x+x,center.y-1+y+.035,center.z+z),amount);
 }
}
