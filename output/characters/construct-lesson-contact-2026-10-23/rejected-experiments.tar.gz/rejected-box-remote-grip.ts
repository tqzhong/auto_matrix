import * as THREE from 'three';
import type { HeroRig } from './HeroModel.js';

function frame(direction:THREE.Vector3):THREE.Quaternion {
 const y=direction.clone().normalize(),z=new THREE.Vector3(0,0,1).addScaledVector(y,-y.z).normalize();
 return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(new THREE.Vector3().crossVectors(y,z),y,z));
}
/** The remote rests against the palm; four fingers and the thumb close on opposite edges. */
export class ConstructRemoteGrip {
 private targets?:THREE.Quaternion[];
 constructor(private rig:HeroRig){}
 update():void {
  if(!this.targets){
   this.targets=[];const skin=this.rig.root.getObjectByName('Anatomical_head_and_hands') as THREE.SkinnedMesh,a=skin.geometry.attributes;
   for(let digit=1;digit<=5;digit++){
    const distal=skin.skeleton.bones.indexOf(this.rig.bones.get(`finger${digit}-3_R`)!),pad=new THREE.Vector3();let count=0;
    for(let id=0;id<a.position.count;id++)for(let k=0;k<4;k++)if(a.skinIndex.getComponent(id,k)===distal&&a.skinWeight.getComponent(id,k)>.95){pad.add(new THREE.Vector3().fromBufferAttribute(a.position,id).applyMatrix4(skin.bindMatrix).applyMatrix4(skin.skeleton.boneInverses[distal]));count++;break;}
    pad.divideScalar(count);const base=this.rig.rest.get(`finger${digit}-1_R`)!,axes=[this.rig.rest.get(`finger${digit}-2_R`)!,this.rig.rest.get(`finger${digit}-3_R`)!,pad];
    const direction=digit===1?new THREE.Vector3(0,-1,0):new THREE.Vector3(1,0,0),tip=digit===1?new THREE.Vector3(.21,-.19,.07):new THREE.Vector3(digit===5?.10:.14,-.331,base.z);
    const end=tip.addScaledVector(direction,-pad.length()),axis=end.clone().sub(base),aa=axes[0].length(),bb=axes[1].length(),length=THREE.MathUtils.clamp(axis.length(),Math.abs(aa-bb)+.001,aa+bb-.001);axis.normalize();end.copy(base).addScaledVector(axis,length);
    const along=(aa*aa-bb*bb+length*length)/(2*length),bend=digit===1?new THREE.Vector3(0,1,0):new THREE.Vector3(-1,0,0);bend.addScaledVector(axis,-bend.dot(axis)).normalize();
    const hinge=base.clone().addScaledVector(axis,along).addScaledVector(bend,Math.sqrt(Math.max(0,aa*aa-along*along))),parent=new THREE.Quaternion();
    [hinge.clone().sub(base),end.clone().sub(hinge),direction].forEach((toward,j)=>{const world=frame(toward).multiply(frame(axes[j]).invert());this.targets!.push(parent.clone().invert().multiply(world));parent.copy(world);});
   }
  }
  for(let digit=1;digit<=5;digit++)for(let joint=1;joint<=3;joint++)this.rig.bones.get(`finger${digit}-${joint}_R`)!.quaternion.copy(this.targets[(digit-1)*3+joint-1]);
  this.rig.bones.get('wrist_R')!.updateWorldMatrix(false,true);
 }
}
