import * as THREE from 'three';import {constructLesson} from './candidate-release/tests/helpers/construct-lesson.mjs';import {ConstructPerformance} from './candidate-release/packages/client/src/agents/ConstructPerformance.js';import {handSurface} from './candidate-release/tests/helpers/hand-surface.mjs';import {inspectionPalm} from './candidate-release/tests/helpers/construct-inspection.mjs';
let grip=.4;const original=ConstructPerformance.prototype.update;
ConstructPerformance.prototype.update=function(input){original.call(this,input);const rig=(this as any).rig;for(let d=1;d<=5;d++)for(let j=1;j<=3;j++)rig.bones.get(`finger${d}-${j}_R`)!.quaternion.identity();(this as any).hands?.pose('R',grip,true);};
const h=await constructLesson('morpheus'),surface=handSurface(h.rig,'R');
for(grip of [.25,.3,.35,.4,.45,.5,.55,.6,.65,.7]){h.at(3);const draw=surface.draw(),points=[...draw.points.values()],g=surface.group,skin=g.skin,inverse=h.rig.bones.get('wrist_R')!.matrixWorld.clone().invert().multiply(skin.matrixWorld),tips=g.tips.map(ids=>ids.map(id=>skin.getVertexPosition(id,new THREE.Vector3()).applyMatrix4(inverse))),palm=h.rig.bones.get('wrist_R')!.worldToLocal(inspectionPalm(h.rig,'R').world);let best:any=null;
for(const degrees of [-75,-60,-45,-30,-15,0,15,30,45,60,75,90])for(let xi=8;xi<=24;xi+=2)for(let yi=-14;yi>=-40;yi-=2){const x=xi/100,y=yi/100,angle=degrees*Math.PI/180,co=Math.cos(angle),si=Math.sin(angle),inward=(p:THREE.Vector3)=>{const dx=p.x-x,dy=p.y-y;return[Math.abs(co*dx+si*dy),Math.abs(-si*dx+co*dy),Math.abs(p.z)];};
if(points.some(p=>{const a=inward(p);return a[0]<.042&&a[1]<.092&&a[2]<.222;}))continue;
const gap=(p:THREE.Vector3)=>{const a=inward(p);return Math.hypot(Math.max(0,a[0]-.045),Math.max(0,a[1]-.095),Math.max(0,a[2]-.225));};
const gaps=tips.map(ps=>Math.min(...ps.map(gap))),cost=Math.max(...gaps)+gap(palm);if(!best||cost<best.cost)best={degrees,x,y,cost,gaps,palmGap:gap(palm)};}
console.log(JSON.stringify({grip,self:draw.self.count,best}));}
h.dispose();
