import * as THREE from 'three';import {constructLesson} from './candidate-release/tests/helpers/construct-lesson.mjs';import {ConstructPerformance} from './candidate-release/packages/client/src/agents/ConstructPerformance.js';import {handSurface} from './candidate-release/tests/helpers/hand-surface.mjs';import {inspectionPalm} from './candidate-release/tests/helpers/construct-inspection.mjs';
let grip=.4;const original=ConstructPerformance.prototype.update;
ConstructPerformance.prototype.update=function(input){original.call(this,input);const rig=(this as any).rig;for(let d=1;d<=5;d++)for(let j=1;j<=3;j++)rig.bones.get(`finger${d}-${j}_R`)!.quaternion.identity();(this as any).hands?.pose('R',grip,true);};
const h=await constructLesson('morpheus'),surface=handSurface(h.rig,'R');
for(grip of [.25,.3,.35,.4,.45,.5,.55,.6,.65,.7]){h.at(3);const draw=surface.draw(),points=[...draw.points.values()],g=surface.group,skin=g.skin,inverse=h.rig.bones.get('wrist_R')!.matrixWorld.clone().invert().multiply(skin.matrixWorld),tips=g.tips.map(ids=>ids.map(id=>skin.getVertexPosition(id,new THREE.Vector3()).applyMatrix4(inverse))),palm=h.rig.bones.get('wrist_R')!.worldToLocal(inspectionPalm(h.rig,'R').world);let best:any=null;
for(let xi=10;xi<=22;xi++)for(let yi=-15;yi>=-35;yi--){const x=xi/100,y=yi/100,box=new THREE.Box3(new THREE.Vector3(x-.045,y-.095,-.225),new THREE.Vector3(x+.045,y+.095,.225)),inside=points.filter(p=>Math.abs(p.x-x)<.042&&Math.abs(p.y-y)<.092&&Math.abs(p.z)<.222).length;
const gaps=tips.map(ps=>Math.min(...ps.map(p=>box.distanceToPoint(p)))),cost=Math.max(...gaps)+box.distanceToPoint(palm);if(!inside&&(!best||cost<best.cost))best={x,y,cost,gaps,palmGap:box.distanceToPoint(palm)};}
console.log(JSON.stringify({grip,self:draw.self.count,best}));}
h.dispose();
