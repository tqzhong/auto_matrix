import * as THREE from 'three';
import { CONSTRUCT,FILM_SETS } from '@auto_matrix/shared';
import { actor,fingerGroups } from './candidate-release/tests/helpers/fighting-hand-fixture.mjs';
import { newMotion,advanceMotion } from './candidate-release/packages/client/src/agents/CharacterMotion.js';
import { handSurface } from './candidate-release/tests/helpers/hand-surface.mjs';
import { wristSwing } from './candidate-release/tests/helpers/core-connector.mjs';
import { inspectionPalm } from './candidate-release/tests/helpers/construct-inspection.mjs';
import { createLoungeChair } from './candidate-release/packages/client/src/engine/LoungeChair.js';
import { crossings } from './candidate-release/tests/helpers/hand-self-contact.mjs';
const center=FILM_SETS.film_white_construct.center;
for(const role of ['neo','morpheus'] as const){
 const h=await actor(role),surfaces=['R','L'].map(side=>handSurface(h.rig,side));
 const chair=createLoungeChair(new THREE.MeshStandardMaterial());chair.position.set(center.x+CONSTRUCT.chairX[role],center.y-1,center.z+CONSTRUCT.chair.z);chair.rotation.y=Math.PI;chair.updateMatrixWorld(true);
 h.rig.root.position.set(center.x+(role==='neo'?CONSTRUCT.neo.x:CONSTRUCT.chairX.morpheus),center.y-1,center.z+(role==='neo'?CONSTRUCT.neo.z:CONSTRUCT.chair.z));h.rig.root.rotation.y=role==='neo'?CONSTRUCT.neo.yaw:Math.PI;
 for(const elapsed of [0,.65,.85,1,1.4,1.65,3,5,6.5,7,7.5,8,9,11]){
  const motion=newMotion(),input={speed:0,grounded:true,verticalVelocity:0,turn:0,clubClothes:role==='neo',performance:'construct' as const,reveal:{kind:'construct' as const,elapsed,role,started:true}};
  h.models.animate(h.rig,advanceMotion(motion,input,0),motion,input,0);h.rig.root.updateMatrixWorld(true);
  const wrists=['R','L'].map(side=>({side,swing:wristSwing(h.rig.bones.get(`wrist_${side}`)!)}));
  const hand=surfaces.map((surface,i)=>{const draw=surface.draw(),inv=h.rig.bones.get(`wrist_${['R','L'][i]}`)!.matrixWorld.clone().invert(),box=new THREE.Box3().setFromPoints([...draw.points.values()]),faces:any[]=[];
   chair.traverse(o=>{if(!(o instanceof THREE.Mesh))return;const geometry=o.geometry,matrix=inv.clone().multiply(o.matrixWorld),p=geometry.attributes.position,idx=geometry.index;for(let f=0;f<(idx?.count??p.count);f+=3){const ids=[0,1,2].map(k=>idx?idx.getX(f+k):f+k),points=ids.map(id=>new THREE.Vector3().fromBufferAttribute(p,id).applyMatrix4(matrix)),bounds=new THREE.Box3().setFromPoints(points);if(box.intersectsBox(bounds))faces.push({face:f/3,ids,points,box:bounds});}});
   const palm=inspectionPalm(h.rig,['R','L'][i] as 'R'|'L'),hit=new THREE.Raycaster(palm.world.clone().add(new THREE.Vector3(0,.3,0)),new THREE.Vector3(0,-1,0),0,2).intersectObject(chair)[0];
   return {side:['R','L'][i],self:draw.self.count,chair:crossings(draw.faces,faces,false).count,palm:palm.world.clone().sub(new THREE.Vector3(center.x,center.y-1,center.z)).toArray(),normal:palm.normal.toArray(),verticalGap:hit?hit.distance-.3:null};});
  let remote:any=null;if(role==='morpheus'){const prop=h.rig.root.getObjectByName('construct-held-remote')!,groups=fingerGroups(h.rig,'R');groups.skin.skeleton.update();const matrix=prop.matrixWorld.clone().invert().multiply(groups.skin.matrixWorld),points=groups.hand.map(id=>groups.skin.getVertexPosition(id,new THREE.Vector3()).applyMatrix4(matrix));remote={inside:points.filter(p=>Math.abs(p.x)<.092&&Math.abs(p.y)<.222&&Math.abs(p.z)<.042).length,box:new THREE.Box3().setFromPoints(points),wrist:h.rig.bones.get('wrist_R')!.quaternion.toArray()};}
  console.log(JSON.stringify({role,elapsed,wrists,hand,remote}));
 }
 if(role==='morpheus'){const groups=fingerGroups(h.rig,'R');console.log(JSON.stringify({rest:groups.tips.map((ids,i)=>({digit:i+1,base:h.rig.rest.get(`finger${i+1}-1_R`)!.toArray(),middle:h.rig.rest.get(`finger${i+1}-2_R`)!.toArray(),end:h.rig.rest.get(`finger${i+1}-3_R`)!.toArray()}))}));}
 h.models.dispose();const geometry=new Set<THREE.BufferGeometry>(),material=new Set<THREE.Material>();chair.traverse(o=>{if(o instanceof THREE.Mesh){geometry.add(o.geometry);material.add(o.material);}});geometry.forEach(g=>g.dispose());material.forEach(m=>m.dispose());
}
