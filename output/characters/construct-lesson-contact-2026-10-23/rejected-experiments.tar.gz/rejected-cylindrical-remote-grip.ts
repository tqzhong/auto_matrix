import * as THREE from 'three';
import type { HeroRig } from './HeroModel.js';
import { ConsoleGrip } from './ConsoleGrip.js';

/** Cache the held remote's fixed wrist-space finger targets. */
export class ConstructRemoteGrip {
 private targets?:THREE.Quaternion[];
 constructor(private rig:HeroRig){}
 update(remote:THREE.Object3D):void {
  if(!this.targets){
   remote.updateWorldMatrix(true,false);
   const skin=this.rig.root.getObjectByName('Anatomical_head_and_hands') as THREE.SkinnedMesh;
   new ConsoleGrip(this.rig).update(skin,1,'handset',1,remote.matrixWorld.clone().multiply(new THREE.Matrix4().makeRotationX(Math.PI)));
   this.targets=Array.from({length:15},(_,i)=>this.rig.bones.get(`finger${Math.floor(i/3)+1}-${i%3+1}_R`)!.quaternion.clone());
  }
  this.targets.forEach((q,i)=>this.rig.bones.get(`finger${Math.floor(i/3)+1}-${i%3+1}_R`)!.quaternion.copy(q));
  this.rig.bones.get('wrist_R')!.updateWorldMatrix(false,true);
 }
}
