import * as THREE from 'three';
import { FILM_SETS, truthRoot } from '@auto_matrix/shared';
import { actor } from './baseline-release/tests/helpers/fighting-hand-fixture.mjs';
import { handSurface } from './baseline-release/tests/helpers/hand-surface.mjs';
import { inspectionPalm } from './baseline-release/tests/helpers/construct-inspection.mjs';
import { wristSwing } from './baseline-release/tests/helpers/core-connector.mjs';
import { newMotion, advanceMotion } from './baseline-release/packages/client/src/agents/CharacterMotion.js';

const h=await actor('neo'),hands=['R','L'].map(side=>handSurface(h.rig,side)),center=FILM_SETS.film_neb_deck.center,floor=center.y-1;
for(const side of ['R','L']as const)inspectionPalm(h.rig,side);
try{
 for(const elapsed of [0,3,5,8,8.4,9.5,10.8,12,13.5]){
  const truth={role:'neo' as const,phase:'unplug' as const,elapsed},root=truthRoot(truth,'neo');h.rig.root.position.set(center.x+root.x,floor+root.y,center.z+root.z);h.rig.root.rotation.y=root.yaw;
  const input={speed:0,grounded:true,verticalVelocity:0,turn:0,realWorld:true,nebCrew:'neo' as const,nebCrewEarly:true,seated:root.seated>0,truth},motion=newMotion();
  h.models.animate(h.rig,advanceMotion(motion,input,0),motion,input,0);h.rig.root.updateMatrixWorld(true);
  const contacts=hands.map((surface,i)=>{const side=['R','L'][i]as 'R'|'L',wrist=h.rig.bones.get('wrist_'+side)!,draw=surface.draw(),palm=inspectionPalm(h.rig,side);return {side,wristSwing:wristSwing(wrist),self:draw.self.count,palmGap:palm.world.y-floor,normalY:palm.normal.y,minimumSkinHeight:Math.min(...[...draw.points.values()].map(p=>p.clone().applyMatrix4(wrist.matrixWorld).y-floor))};});
  console.log(JSON.stringify({elapsed,root,contacts}));
 }
}finally{h.models.dispose();}
